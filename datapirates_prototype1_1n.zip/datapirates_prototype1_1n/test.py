# Necessary Libraries for flask
from flask import Flask, request, render_template, session, redirect

# Necessary labraries 
import numpy as np
import pandas as pd
import sklearn

#necessary libraries for visualization
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud

#necessary libraries for ignoring warnings
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

#necessary libraries for tokenisation
from rake_nltk import Rake
from gensim.models.doc2vec import Doc2Vec, TaggedDocument
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from flask import render_template_string

#Import TfIdfVectorizer from scikit-learn
from sklearn.feature_extraction.text import TfidfVectorizer
# Import linear_kernel
from sklearn.metrics.pairwise import linear_kernel
# Compute the Cosine Similarity matrix based on the count_matrix
from sklearn.metrics.pairwise import cosine_similarity
# Import CountVectorizer and create the count matrix
from sklearn.feature_extraction.text import CountVectorizer


from scipy import sparse
from sklearn.metrics.pairwise import cosine_similarity


app = Flask(__name__)
# Loading the required datasets
movies=pd.read_csv("final.csv")
actors = pd.read_excel("actor1.xlsx")
dflask = movies.head(30)
actorsData = actors.head(30)
mean_vote= movies['vote_average'].mean()
min_vote= movies['vote_count'].quantile(0.8)
movie_list = movies['movie_name'].unique()
indices = pd.Series(movies.index, index=movies['movie_name']).drop_duplicates()


"""
 AUTHOR: Kavya Konisa	
 NAME: demogrphic
 PARAMETERS: None
 PURPOSE: The function calculate the score for every movie , sort the scores and recommend the best rated top 10 movies to the users.
 PRECONDITION:  We should be able to calculate the Tmdb score to retrieve top elements.
 POSTCONDITION: It appends all the movie_name, vote_count, vote_average, rating,year to the top_movies dataframe
 """
def demogrphic(): 
    top_movies = movies.copy().loc[movies['vote_count'] >= min_vote]
    # Applying weighted_rating to calculate top movies
    top_movies['rating'] = top_movies.apply(weighted_imdb_rating, axis=1)
    top_movies = top_movies.sort_values('rating', ascending=False)
    return top_movies[['movie_name', 'vote_count', 'vote_average', 'rating','year']].head(10)

"""
 AUTHOR: Kavya Konisa	
 NAME: get_recommendations
 PARAMETERS: movie- Name of the movie and cosine_sim - the cosine_similarity caluculated
 PURPOSE: The function to get recommendations based on the similarity scores of all movies
 PRECONDITION: Movie is case sensitive.
 POSTCONDITION: It return the movie_name, genre,tyear, overview of the similar movies
 """
def get_recommendations(movie, cosine_sim):
    # calculate the index of the movie that matches the title
    idx = get_index(movie)
    # check if there are any ids with the mvie name
    if idx == -1:
        message="Asked movie is not available in the database"
        return message
    # calculate the pairwsie similarity scores of all movies with that movie and Sort the movies based on the similarity scores
    sim_scores = sorted(list(enumerate(cosine_sim[idx])), key=lambda x: x[1], reverse=True)
    # Calculate the scores of the 10 most similar movies and  Get the movie indices
    movie_indices = [i[0] for i in sim_scores[1:11]]
    recommended_movies = movies[['movie_name', 'genre','year', 'overview']].iloc[movie_indices]
    # Return the top 10 most similar movies    
    return recommended_movies.head(10)
"""
 AUTHOR: Kavya Konisa	
 NAME: content_based_overview
 PARAMETERS: movie_given - Name of the movie 
 PURPOSE: The function to find the similarity scores of all the given movie based on overview
 PRECONDITION: Movie is case sensitive.
 POSTCONDITION: It return the movie_name, genre,year, overview of the similar movies
 """
def content_based_overview(movie_given):
    #Defining a TF-IDF Vectorizer Object using Stop words to neglect unnecessary words
    tfidf = TfidfVectorizer(analyzer='word',ngram_range=(1, 2),min_df=0, stop_words='english')
    movies['overview'] = movies['overview'].fillna('')
    #Construct the required TF-IDF matrix by fitting and transforming the data and caluculate the cosine similarity matrix
    tfidf_matrix = tfidf.fit_transform(movies['overview'])
    cosine_sim = linear_kernel(tfidf_matrix, tfidf_matrix)
    recommended_movies = get_recommendations(movie_given, cosine_sim)
    return recommended_movies

"""
 AUTHOR: Kavya Konisa	
 NAME: content_based_genre
 PARAMETERS: movie_given- Name of the movie 
 PURPOSE: The function to find the similarity scores of all the given movie based on genre
 PRECONDITION: Movie is case sensitive.
 POSTCONDITION: It return the movie_name, genre,year, overview of the similar movies
 """
def content_based_genre(movie_given):
    #Defining a TF-IDF Vectorizer Object using Stop words to neglect unnecessary words
    tfidf = TfidfVectorizer(analyzer='word',ngram_range=(1, 2),min_df=0, stop_words='english')
    movies['genre'] = movies['genre'].fillna('')
    #Construct the required TF-IDF matrix by fitting and transforming the data and caluculate the cosine similarity matrix
    tfidf_matrix = tfidf.fit_transform(movies['genre'])
    cosine_sim = linear_kernel(tfidf_matrix, tfidf_matrix)
    recommended_movies = get_recommendations(movie_given, cosine_sim)
    return recommended_movies

"""
 AUTHOR: Kavya Konisa	
 NAME: bags_of_words_model
 PARAMETERS: movie_given- Name of the movie 
 PURPOSE: The function to find the similarity scores of all the given movie based on bags of words model
 PRECONDITION: Movie is case sensitive.
 POSTCONDITION: It return the movie_name, genre,year, overview of the similar movies
 """
def bags_of_words_model(movie_given):
    global movies
    movies["genre"] = movies["genre"].apply(lambda x: x.replace("|"," "))
    movies["keywords"] = movies["keywords"].apply(lambda x: x.replace("|"," "))
    #create bag of words model
    movies['bag_of_words'] = movies.apply(create_BOW, axis=1)
    count = CountVectorizer(stop_words='english')
    count_matrix = count.fit_transform(movies['bag_of_words'])
    cosine_sim = cosine_similarity(count_matrix, count_matrix)
    # Reset index of our main DataFrame and construct reverse mapping as before
    movies =  movies.reset_index(drop=True)
    indices = pd.Series(movies.index, index=movies['movie_name']).drop_duplicates()
    recommended_movies = get_recommendations(movie_given, cosine_sim)
    return recommended_movies


"""
 AUTHOR: Kavya Konisa	
 NAME: create_BOW
 PARAMETERS: movie- Name of the movie 
 PURPOSE: The function to create bags of words model for a given movie by joining all the keywords, genre,director and cast.
 PRECONDITION: Movie is case sensitive.
 POSTCONDITION: It return the movie_name, genre,year, overview of the similar movies
 """
def create_BOW(movie):
    return ' '.join(movie['keywords']) + ' ' + ' '.join(movie['cast']) + ' ' + movie['director'] + ' ' + ' '.join(movie['genre'])


"""
 AUTHOR: Kavya Konisa	
 NAME: get_index
 PARAMETERS: movie- Name of the movie 
 PURPOSE: The function is used to get the index of the movie using indices function
 PRECONDITION: Movie is case sensitive.
 POSTCONDITION: It return either -1 if movie is not present or id iof the movie name
 """
def get_index(movie):
    if movie not in movie_list:
        return -1
    else:
        return indices[movie]


"""
 AUTHOR: Kavya Konisa	
 NAME: weighted_imdb_rating
 PARAMETERS: data - movies dataframe, mean_vote - is the mean vote across the whole report, min_vote - the minimum votes required to be listed in the chart
 PURPOSE: The function calculates the weighted imdb rating
 PRECONDITION: mean_vote should not be zero
 POSTCONDITION: It returns the rating calculated for each movie
 """

def weighted_imdb_rating(data, mean_vote=mean_vote, min_vote=min_vote):
    count_vote = data['vote_count']
    avg_vote = data['vote_average']
    rating =  (count_vote/(count_vote+min_vote) * avg_vote) + (min_vote/(min_vote+count_vote) * mean_vote)
    return round(rating, 3)


"""
 AUTHOR: Kavya Konisa	
 NAME: html_table
 PARAMETERS: None
 PURPOSE: The function returns a simple html home page
 PRECONDITION: None
 POSTCONDITION: It appends details to the table in the html page
 """
@app.route('/')
def html_table():
    return render_template('flaskm.html',  tables=[dflask.to_html(classes='data')], titles=dflask.columns.values)



"""
 AUTHOR: Kavya Konisa	
 NAME: show_movies
 PARAMETERS: None
 PURPOSE: The function returns the movie information that we have scraped in the last project from tmdb website
 PRECONDITION: None
 POSTCONDITION: It appends details to the table in the html page
 """
@app.route('/movies')
def show_movies():
    return render_template('movies.html', tables=[dflask.to_html(classes='data')], titles=dflask.columns.values)


"""
 AUTHOR: Kavya Konisa	
 NAME: show_actors
 PARAMETERS: None
 PURPOSE: The function returns the actors that we have scraped in the last project from tmdb website
 PRECONDITION: None
 POSTCONDITION: It appends details to the table in the html page
 """
@app.route('/actors')
def show_actors():
    return render_template('movies.html', tables=[actorsData.to_html(classes='data')], titles=actorsData.columns.values)

"""
 AUTHOR: Kavya Konisa	
 NAME: show_highest
 PARAMETERS: None
 PURPOSE: The function returns the top popular movies recommended in a form of table based on rating.
 PRECONDITION:  None
 POSTCONDITION: It returns the popular movies in a html table format
 """
@app.route('/highest')
def show_highest():
    top_movies= demogrphic()
    return render_template('movies.html', tables=[top_movies.to_html(classes='data')], titles=top_movies.columns.values)


"""
 AUTHOR: Kavya Konisa	
 NAME: show_recommend_overview
 PARAMETERS: None
 PURPOSE: The function returns the similar movies recommended in a form of table based on overview.
 PRECONDITION:  Movie is case sensitive.
 POSTCONDITION: It returns the recommended movies in a html table format
 """
@app.route('/recommend_overview')
def show_recommend_overview():
    movie = request.args.get('movie')
    print(movie)
    recommended_movies= content_based_overview(movie)
    if type(recommended_movies)==type('string'):
        return "<h2>Sorry! Movie is not in the Database</h2>"       
    else:
        recommended_movies = pd.DataFrame(recommended_movies)

        print(recommended_movies)
        return render_template('movies.html', tables=[recommended_movies.to_html(classes='data')], titles=str(recommended_movies.columns.values).upper())

"""
 AUTHOR: Kavya Konisa	
 NAME: show_recommend_genre
 PARAMETERS: None
 PURPOSE: The function returns the similar movies recommended in a form of table.
 PRECONDITION:  Movie is case sensitive.
 POSTCONDITION: It returns the recommended movies in a html table format
 """
@app.route('/recommend_genre')
def show_recommend_genre():
    movie = request.args.get('movie')
    print(movie)
    recommended_movies= content_based_genre(movie)

    if type(recommended_movies)==type('string'):
        return render_template_string('hello {{ what }}', what='Movie is not in database')        
    else:
        recommended_movies = pd.DataFrame(recommended_movies)

        print(recommended_movies)
        return render_template('movies.html', tables=[recommended_movies.to_html(classes='data')], titles=recommended_movies.columns.values)

"""
 AUTHOR: Kavya Konisa	
 NAME: show_recommend_bow
 PARAMETERS: None
 PURPOSE: The function returns the similar movies recommended in a form of table.
 PRECONDITION:  Movie is case sensitive.
 POSTCONDITION: It returns the recommended movies in a html table format
 """
@app.route('/recommend_BOW')
def show_recommend_bow():
    movie = request.args.get('movie')
    print(movie)
    recommended_movies= bags_of_words_model(movie)
    print(recommended_movies)
    if type(recommended_movies)==type('string'):
        return "<h2>Sorry! Movie is not in the Database</h2>"       
    else:
        recommended_movies = pd.DataFrame(recommended_movies)
        print(recommended_movies)
        return render_template('movies.html', tables=[recommended_movies.to_html(classes='data')], titles=recommended_movies.columns.values)


"""
 AUTHOR: Kavya Konisa
 FILENAME: test.py
 SPECIFICATION: It recommends the similar movies for a given movie name considering various features of the movie information
 FOR: CS  5364 – Information Retrieval Section 001

"""
if __name__ == '__main__':
    app.run(port=4998)